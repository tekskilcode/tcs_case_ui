import json
import docker
import os
MANIFEST = "manifest.json"
images = []
def load_manifest():
    with open(MANIFEST, "r") as f:
        manifest_data = json.load(f)
        #print(manifest_data)
        # for each image concat image_name + version 
        for image in manifest_data["images"]:
            images.append(image["image_name"] + ":" + image["version"])
        print(images)

def pull_docker_image(image_name):
    client = docker.from_env()
    print(f"Checking if image {image_name} exists locally...")
    local_images = [tag for image in client.images.list() for tag in image.tags]
    if image_name not in local_images:
        print(f"Image {image_name} not found locally. Pulling from registry...")
        image = client.images.pull(image_name)
        print(f"Pulled {image_name} successfully.")
    else:
        print(f"Image {image_name} found locally.")    
  

load_manifest()
for image in images:
     pull_docker_image(image)