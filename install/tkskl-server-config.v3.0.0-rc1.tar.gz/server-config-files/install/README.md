## Basic Tekskil Server and Docker images install

run `install.sh` to setup  tekskil server
 this script will:
 - copy bash_aliases to user home directory
 - copy daemon.json to /etc/docker
 - create synlinks for the control hub docker-compose files
 - pull images from private repo



