## base install script for server-config-files

## confirm docker is installed
if ! [ -x "$(command -v docker)" ]; then
  echo 'Error: docker is not installed.' >&2
  exit 1
fi

# save daemon.json to /ect/docker/daemon.json
echo "Copying daemon.json to /etc/docker/daemon.json"
sudo cp ./files/daemon.json /etc/docker/daemon.json

# restart docker
echo "Restarting docker"
sudo systemctl restart docker

## copy .bash_aliases to home directory
echo "Copying .bash_aliases to home directory"
cp ./files/.bash_aliases ~/.bash_aliases


## pull docker images using pull_images.py
echo "Pulling docker images"
python3 ./pull_images.py

# create symling for compose file data
echo "Creating symlink for compose file data"
ln -snf ../orchestrator/data/compose-files ~/apps/docker/ctrl-hub-compose


