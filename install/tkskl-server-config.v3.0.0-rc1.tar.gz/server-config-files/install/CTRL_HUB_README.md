## CONTROL HUB INSTALLATION



For both panasonic and sony control hubs, the following steps should be taken:
create a directory for the control hub named to match the corresponding camera.  For example, if the camera is named camera-1, the directory should be named camera-1.  This directory should be created in the orchestrator/data/compose-files directory.  The directory should contain the following files:
- camera-1.panasonic-ctrl-hub.docker-compose.yml or camera-1.sony-ctrl-hub.docker-compose.yml
- sym-link to the orchestrator/data/compose-files/ctrl-hub.env ==> camera-1/.env
- sym-link from sony or panasonic ctrl hub file to docker-compose.yml 

### Panasonic

####  Firmware Update
 - AW-RP150 and AW-RP120 require the latest firmware to work with the Control Hub.
    - The latest firmware can be found on the Panasonic website.

`orchestrator/data/compose-files/camera-1/camera-1.panasonic-ctrl-hub.docker-compose.yml`
should be used as a template for the Panasonic control hub.  

### Sony
Sony control hubs require a ipvlan be created on the host machine.  This is done by running the following script:
- open compose-files/scripts/create_network.sh
- update the SUB and GATE variables to match the network configuration
- run the script

`orchestrator/data/compose-files/camera-1/camera-1.sony-ctrl-hub.docker-compose.yml`
should be used as a template for the Sony control hub.




