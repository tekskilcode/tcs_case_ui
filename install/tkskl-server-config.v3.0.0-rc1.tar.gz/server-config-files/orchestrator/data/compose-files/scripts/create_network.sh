SUB='0.0.0.0/24' # The subnet for the ipvlan
GATE='0.0.0.1' # The gateway for the ipvlan

NETWORK_NAME='tkskl-srvr-vlan'

function network_exist(){
   local CONFIRM=$(docker network ls | grep $NETWORK_NAME | wc -l)
   # echo $CONFIRM
   if test $CONFIRM -eq 1
    then
        echo true
    else
        echo  false
    fi
}

function create_network(){
    echo "Creating docker ipvlan on eth0"
    docker network create -d ipvlan --subnet $SUB --gateway $GATE -o parent=eth0 $NETWORK_NAME
    local confirmCreate=$(network_exist)
    if [ "$confirmCreate" = true ] ; then
        echo "Created $NETWORK_NAME"
    else
        echo "Error Creating ipvlan: $NETWORK_NAME"
    fi
}




hasNetwork=$(network_exist)

if [ "$hasNetwork" = true ] ; then
      echo "ipvlan network $NETWORK_NAME already exist"
    else
        create_network
fi
